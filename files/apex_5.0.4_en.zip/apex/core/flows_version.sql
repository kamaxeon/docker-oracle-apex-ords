set define '^' verify off
prompt ...wwv_flows_version
create or replace function wwv_flows_version wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
7b 8d
Llo50rYMYIu7cjjPgDH9R7V/YmQwg8eZgcfLCNL+XhaWlm2u2fqWlkqWDGLF/0dyXufAsr2y
m17nx3TAM7h0ZQm4dIsVsm5xVQBzU46ppvCp7FFIkXAR2Bdw56L8PHHiP9E8dKZ2D4iZ

/
