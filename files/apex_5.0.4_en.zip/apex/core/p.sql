set define '^' verify off
prompt ...p
create or replace procedure p wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
1da 140
YoP75MOuXMUXaFcMCUjDTLkZ+h0wg2NpLZ4VfC8yuepoPG8a1vbM4zPsOfH2WgkMsMoWZleJ
yz+dDWJh1gaP/RXtaAgZmOvoenAriEZvZsp1qOdKR3aeyd/IOP/FKanFPrH75Kkz8hbS4rPO
nBjKPuedAb0mdKg5ydautO8fISPjNJoMtK9vcTchuh/cSXvlHoxyAZMS+uNJYS3LjeoRYoYE
AnmbV1UgF5pB4h+qKUV8SuuTrw4KdC4sWpO73/cIEPbB5lHqaBR2VWfKnm8KyUtV+zvWrniK
2plFbljRIXRfMk/NjeawCkltbMlZ

/
show errors
