set define '^' verify off
prompt ...wwv_flow_init_htp_buffer
create or replace procedure wwv_flow_init_htp_buffer wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
6b 92
5mSVK8mr5GZKS+U0M0dzYxd2dZcwg5nnm7+fMr2ywFwWlpZtrtn6ltByR9lW9HIWPuOuxS4M
DGIJuHSL5kTc4rlBP3GeZ6lgRgcHlZg6zgfGW745W874RJj8+4jiqDxx4j/RPHSmNhCrFA==


/
show errors
