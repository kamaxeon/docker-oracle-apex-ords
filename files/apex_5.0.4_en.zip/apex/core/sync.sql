set define '^'
set verify off
prompt ...wwv_flow_sync_translations
create or replace procedure wwv_flow_sync_translations wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
141 103
vdyA7LxrMXIaibS8riK6HuwW0lUwg/BKrpmsZ47b2ruwtAus9X3FRJa/DVvZXjOuJd73yuei
qGwpBR/JWPXeSGp8gp1xFy2O3AwZ/niq4uwZxP6SXZj2k8RcMUzsRUMM1E+XEFHCFYyPgqgI
HX0wKCPXAlndPtn6PpRKbESJe1pDD2Op10ZAzZEYIVmUle7pcCrIzHB/77tWxaAW15d2PvlK
R+MASZp+SR/cOlvAhZrR4wS3FOjBT9ARCKbYr2k8

/
show errors
