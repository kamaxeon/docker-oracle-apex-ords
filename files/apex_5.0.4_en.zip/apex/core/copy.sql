set define '^'
set verify off
prompt ...wwv_flow_copy
create or replace procedure wwv_flow_copy wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
2cc 175
d/RBQc5jXmAfkkoAeM8Ukv2LCPUwgxD3mNzbfC/pJnOU0ZPe6TX6J/cb+hRUWXr3LP3MvmdR
5qPFZvlBcDyjSX9Z94tBx5RMKED2fjQ1rS5P7s1zegKxTsacNJTAvKig2wtpLhGy/mWQJQn4
vOYDD8xKY+QT4QlwnFka3HD8SXz+wq9ver6T76PDtn3/hAeh/xrbCE52QDm9pGApFVxHRg5D
asxhZ2+2JA7eMdKviFCn3T48n5XahlJJYbDYTUtee9+NIoYwknO72HowsFqtAjPRYCoolpyN
tZOSzlPyM0QLLX0VuG5OlXPvT/Eu+CPO9hKnXSsIiFENocA7zqvM1WyY1i9NEx7/JAscSLz7
6SgKZQ==

/
show errors
